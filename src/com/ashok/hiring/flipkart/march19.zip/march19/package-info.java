/**
 * Problem: Finite State Machine.
 * Design an fsm where multiple producers can send event and multiple subscribers can subscribe to transitions.
 *
 * @author Ashok Rajpurohit (ashok1113@gmail.com).
 */
package com.ashok.hiring.flipkart.march19;